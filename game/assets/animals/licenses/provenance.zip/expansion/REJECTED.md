# Candidats hors livraison

- Innerscene `inner_pigeon`, `inner_sparrow`, `inner_duck`, `inner_squirrel` : silhouettes de jouets, yeux et surfaces stylisés. Sources CC0, rejet visuel.
- Grab3D `grab_black_cat`, `grab_octopus` : yeux disproportionnés et apparence cartoon. Rejet visuel.
- Grab3D serpent : modèle enroulé ; aucune préparation de rig satisfaisante dans cette sélection. Non livré.
- BlenderKit `bk_tonbo` : fichier incompatible avec l’import Blender 4.2 utilisé. Non livré.
- BlenderKit `bk_fishing_spider` : modèle réaliste, mais le modèle de Nik Kottmann est plus léger et possède une animation originale ; variante redondante non préparée.
- Objaverse `obj_gecko_house` : archive anciennement marquée `by`, page actuelle CC BY-NC 4.0 ; preuve historique de version non suffisante. Aucune promotion.
- Objaverse `obj_frog_green` : archive marquée `by`, page actuelle sans licence. Aucune promotion.
- Objaverse `obj_mouse_house`, `obj_pigeon_gray`, `obj_pigeon_white`, `obj_rat_white` : absence de confirmation de version de licence accessible lors du contrôle. Les GLB restent des candidats, non livrés.
- OpenGameArt escargot : coquille seule, sans corps ; ne constitue pas un escargot complet.
- OpenGameArt petit oiseau brun : source OBJ sans texture portable exploitable dans l’archive vérifiée ; non livré.

Les modèles distribués dans le jeu sont uniquement ceux du manifeste `game/assets/animals/manifest.json`. Les dossiers de recherche ne constituent pas une autorisation générale de redistribution des candidats.
